document.body.style.backgroundColor='red';
